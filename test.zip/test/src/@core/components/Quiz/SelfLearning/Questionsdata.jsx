import React from 'react'

  // total questions
  const Questionsdata = [
    {
      id: "1",
      questions: "5",
    },
    {
      id: "2",
      questions: "10",
    },
    {
      id: "3",
      questions: "15",
    },
    {
      id: "4",
      questions: "20",
    },
    {
      id: "5",
      questions: "25",
    },
    {
      id: "6",
      questions: "30",
    },
    {
      id: "7",
      questions: "35",
    },
    {
      id: "8",
      questions: "40",
    },
    {
      id: "9",
      questions: "45",
    },
    {
      id: "10",
      questions: "50",
    },
    {
      id: "11",
      questions: "55",
    },
    {
      id: "12",
      questions: "60",
    },
  ];

export default Questionsdata