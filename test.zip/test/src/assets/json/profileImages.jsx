
const profileImages = [
    {
        id: 1,
        img: "/images/profileimages/1.svg",

    },
    {
        id: 2,
        img: "/images/profileimages/2.svg",

    },
    {
        id: 3,
        img: "/images/profileimages/3.svg",

    },
    {
        id: 4,
        img: "/images/profileimages/4.svg",

    },
    {
        id: 5,
        img: "/images/profileimages/5.svg",

    },
    {
        id: 6,
        img: "/images/profileimages/6.svg",

    },
    {
        id: 7,
        img: "/images/profileimages/7.svg",

    },
    {
        id: 8,
        img: "/images/profileimages/8.svg",

    },
    {
        id: 9,
        img: "/images/profileimages/9.svg",

    },
    {
        id: 10,
        img: "/images/profileimages/10.svg",

    },
]

export {profileImages}