import React from 'react'
import Home from './home'

const index = () => {
  return (
    <div><Home/></div>
  )
}

export default index